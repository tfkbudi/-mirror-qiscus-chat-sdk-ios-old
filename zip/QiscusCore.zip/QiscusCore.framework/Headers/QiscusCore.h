//
//  QiscusCore.h
//  QiscusCore
//
//  Created by Qiscus on 16/07/18.
//  Copyright © 2018 Qiscus. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for QiscusCore.
FOUNDATION_EXPORT double QiscusCoreVersionNumber;

//! Project version string for QiscusCore.
FOUNDATION_EXPORT const unsigned char QiscusCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QiscusCore/PublicHeader.h>


